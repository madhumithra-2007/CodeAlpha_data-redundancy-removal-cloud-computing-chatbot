# Task 1 — Data Redundancy Removal System

## Objective
Identify duplicate records, validate new data, and prevent duplicate entries in a database.

## Features
- Form to enter name, email, and phone number.
- Input validation for empty fields, email format, and phone number.
- Duplicate detection using a unique email constraint in SQLite.
- Displays stored records and allows CSV export.

## Run on Windows
1. Install Python 3.10 or later.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```bash
   python -m pip install -r requirements.txt
   streamlit run app.py
   ```
5. A browser tab opens. Add a record, then try submitting the same email again to test duplicate detection.

## Database
The app automatically creates `records.db` in this folder when it runs. Do not delete it if you want to keep your saved records.

## Test cases
| Test | Input | Expected result |
|---|---|---|
| Valid new record | New name, valid email, 10+ digit phone | Saved |
| Same email again | Previously used email | Duplicate rejected |
| Invalid email | `abc` | Validation error |
| Short phone | Fewer than 10 digits | Validation error |
| Empty field | Leave one field blank | Validation error |

## Note
This is a local demonstration of a cloud-ready application. To deploy it publicly, connect it to a managed database and host it on a cloud platform.
