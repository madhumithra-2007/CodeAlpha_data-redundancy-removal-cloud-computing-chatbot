import sqlite3
import re
import streamlit as st
import pandas as pd
from pathlib import Path

DB_PATH = Path(__file__).with_name("records.db")

def connect():
    return sqlite3.connect(DB_PATH)

def init_db():
    with connect() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                phone TEXT NOT NULL
            )
        """)

def valid_email(email):
    return re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email.strip()) is not None

def add_record(name, email, phone):
    name, email, phone = name.strip(), email.strip().lower(), phone.strip()
    if not name or not email or not phone:
        return False, "Please fill in all fields."
    if not valid_email(email):
        return False, "Enter a valid email address."
    if not phone.isdigit() or len(phone) < 10:
        return False, "Phone number must contain at least 10 digits."
    try:
        with connect() as con:
            con.execute(
                "INSERT INTO records (name, email, phone) VALUES (?, ?, ?)",
                (name, email, phone)
            )
        return True, "Record added successfully. No duplicate found."
    except sqlite3.IntegrityError:
        return False, "Duplicate detected: this email already exists."

def load_records():
    with connect() as con:
        return pd.read_sql_query(
            "SELECT id, name, email, phone FROM records ORDER BY id DESC", con
        )

st.set_page_config(page_title="Data Redundancy Removal", page_icon="🗂️")
init_db()
st.title("🗂️ Data Redundancy Removal System")
st.write("A simple cloud-ready database application that validates records and prevents duplicate entries.")

with st.form("record_form"):
    st.subheader("Add a new record")
    name = st.text_input("Name")
    email = st.text_input("Email")
    phone = st.text_input("Phone number")
    submitted = st.form_submit_button("Validate and save")

if submitted:
    success, message = add_record(name, email, phone)
    (st.success if success else st.error)(message)

st.divider()
st.subheader("Stored records")
data = load_records()
st.metric("Unique records stored", len(data))
if data.empty:
    st.info("No records yet. Add your first record above.")
else:
    st.dataframe(data, use_container_width=True, hide_index=True)
    csv = data.to_csv(index=False).encode("utf-8")
    st.download_button("Download records as CSV", csv, "unique_records.csv", "text/csv")

st.caption("Duplicate rule: email addresses must be unique. SQLite enforces this rule even if two users submit the same email.")
