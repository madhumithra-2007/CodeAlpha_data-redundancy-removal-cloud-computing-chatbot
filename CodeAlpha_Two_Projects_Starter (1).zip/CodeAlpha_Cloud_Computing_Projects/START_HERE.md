# CodeAlpha Cloud Computing — Starter Projects

This package contains two beginner-friendly projects:
1. Task1_Data_Redundancy_Removal
2. Task4_Chatbot

## Important
These are working starter implementations for learning and testing. Before submitting:
- Run both projects on your own laptop.
- Test the features and take your own screenshots.
- Read and understand the code so you can explain it in your internship video.
- Follow the exact submission instructions and deadline given by your internship coordinator.
- Do not claim that a local demo is cloud-hosted. The READMEs explain the current scope.

Each project has its own `requirements.txt` and `README.md`.
