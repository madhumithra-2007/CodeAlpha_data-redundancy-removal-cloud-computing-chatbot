import streamlit as st
from datetime import datetime

FAQ = {
    "hello": "Hello! Welcome to the CodeAlpha Help Chatbot. How can I help you?",
    "hi": "Hi! Ask me about cloud computing, Python, databases, or this chatbot.",
    "cloud computing": "Cloud computing provides computing services such as servers, storage, databases, and software over the internet.",
    "what is cloud": "Cloud computing means using internet-based servers and services instead of relying only on your own computer.",
    "python": "Python is a beginner-friendly programming language used in web development, automation, data science, and AI.",
    "database": "A database is an organized collection of information. SQLite is the lightweight database used in the Data Redundancy project.",
    "sql": "SQL stands for Structured Query Language. It is used to create, read, update, and delete data in relational databases.",
    "chatbot": "A chatbot is a software application that interacts with users through text or voice. This demo uses keyword matching to select answers.",
    "internship": "An internship gives students practical experience. Follow your organization's official instructions and submit only genuine work.",
    "thank you": "You're welcome! Have a great day.",
    "thanks": "You're welcome! Feel free to ask another question."
}

def get_reply(message):
    cleaned = message.lower().strip()
    if not cleaned:
        return "Please type a question."
    # Match the longest known keyword first.
    for keyword in sorted(FAQ, key=len, reverse=True):
        if keyword in cleaned:
            return FAQ[keyword]
    return ("I don't have an answer for that yet. Try asking about cloud computing, "
            "Python, databases, SQL, chatbots, or internships.")

st.set_page_config(page_title="Cloud Computing Chatbot", page_icon="💬")
st.title("💬 Cloud Computing Help Chatbot")
st.write("A simple FAQ chatbot using predefined question patterns and responses.")

if "messages" not in st.session_state:
    st.session_state.messages = [
        {"role": "assistant", "content": "Hello! Ask me a question about cloud computing or programming."}
    ]

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

prompt = st.chat_input("Type your question here...")
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    reply = get_reply(prompt)
    st.session_state.messages.append({"role": "assistant", "content": reply})
    st.rerun()

with st.sidebar:
    st.subheader("Try these questions")
    for sample in ["What is cloud computing?", "Explain Python", "What is a database?", "What is SQL?", "What is a chatbot?"]:
        st.write("• " + sample)
    if st.button("Clear conversation"):
        st.session_state.messages = []
        st.rerun()
    st.caption("Demo version • " + datetime.now().strftime("%d %b %Y"))
