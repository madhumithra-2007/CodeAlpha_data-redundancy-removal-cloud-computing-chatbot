# Task 4 — Cloud Computing Help Chatbot

## Objective
Create a chatbot that responds to common user questions through predefined input patterns.

## Features
- Chat-style interface.
- Predefined responses for common questions.
- Keyword matching, checking longer phrases first.
- Fallback response for questions it does not recognize.
- Clear conversation option.

## Run on Windows
1. Install Python 3.10 or later.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   ```bash
   python -m pip install -r requirements.txt
   streamlit run app.py
   ```
5. Type a question in the chat box.

## Example questions
- What is cloud computing?
- Explain Python.
- What is a database?
- What is SQL?
- What is a chatbot?

## How it works
The app stores a small FAQ dictionary. When a user sends a message, the program checks whether it contains a known keyword and returns the corresponding answer. If no keyword matches, it returns a helpful fallback message.

## Limitation
This is a retrieval/keyword-based educational chatbot, not a generative AI model. Responses are limited to the predefined knowledge base.
